using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamFollow : MonoBehaviour
{
    public Transform player; // The player's transform
    public float smoothing = 5f; // The speed of the camera's movement

    Vector3 offset; // The offset of the camera from the player

    // Called when the script is first initialized
    void Start()
    {
        offset = transform.position - player.position; // Calculate the offset between the camera and player
    }

    // Called every frame
    void Update()
    {
        Vector3 targetCamPos = player.position + offset; // Calculate the target position of the camera
        transform.position = Vector3.Lerp(transform.position, targetCamPos, smoothing * Time.deltaTime); // Move the camera smoothly towards the target position
    }
}
