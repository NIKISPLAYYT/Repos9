using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class menuManager : MonoBehaviour
{
    public GameObject options;
    public void Exit()
    {
        Application.Quit();
        Debug.Log("Game quit");
    }

    public void Settings()
    {
        options.SetActive(true);
    }

    public void ExitSettings()
    {
        options.SetActive(false);
    }

    public void Play()
    {
        SceneManager.LoadScene(0);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            options.SetActive(false);
        }
    }
}
