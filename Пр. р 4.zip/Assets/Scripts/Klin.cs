using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Klin : MonoBehaviour
{
    /*public GameObject cubePrefab;
    public int wedgeSize = 3;
    private int k = 1;
    private int l = 1;
    private int d = 1;*/

    public GameObject cubePrefab;
    public int rowCount = 5;
    public float offset = 0.5f;

    private void Start()
    {
        /*for (int i = 0; i < wedgeSize; i++)
        {
            GameObject cube = Instantiate(cubePrefab, transform);

            cube.transform.position = new Vector3(i * 1f, i * 2f, 0f);//0.5
        }
        for (int i = 0; i < wedgeSize; i++)
        {
            GameObject cube = Instantiate(cubePrefab, transform);

            cube.transform.position = new Vector3(i * -1f, i * 2f, 0f);//0.5
        }
        for (int i = 0; i < wedgeSize; i++)
        {
            k++;
            GameObject cube = Instantiate(cubePrefab, transform);

            cube.transform.position = new Vector3(k * 0f, k * 2f, 0f);//0.5
        }
        for (int i = 0; i < wedgeSize; i++)
        {
            k++;
            l++;
            GameObject cube = Instantiate(cubePrefab, transform);

            cube.transform.position = new Vector3(2f, l * 2f, 0f);//0.5
        }
        for (int i = 0; i < wedgeSize; i++)
        {
            k++;
            d++;
            GameObject cube = Instantiate(cubePrefab, transform);

            cube.transform.position = new Vector3(-2f, d * 2f, 0f);//0.5
        }*/
        for (int i = 0; i <rowCount; i++)
        {
            for(int j = 0; j < i + 1; j++)
            {
                float xPos = j * offset - i * offset / 2;
                float yPos = -i * offset;
                Vector3 spawnPosition = new Vector3 (xPos, yPos, 0);
                Instantiate(cubePrefab, spawnPosition, Quaternion.identity);
            }
        }


    }
}
