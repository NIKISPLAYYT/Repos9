using System.Collections;
using System.Collections.Generic;
using TMPro;
using TMPro.Examples;
using UnityEngine;
using UnityEngine.UI;

public class Dialog : MonoBehaviour
{
    public string[] dialog;
    private int count;
    public TMP_Text text;
    public GameObject dialogWindow;
    private bool isTalking = false;


    // Update is called once per frame

    void Update()
    {
        if (isTalking == false)
        {
            text.text = dialog[count];
        }
        else
        {
            dialogWindow.SetActive(false);
        }
        
    }

    public void Next()
    {
        count++;
        if (count > 4)
        {
            count = 4;
        }
    }
    public void Prev()
    {
        count--;
        if (count <= 0)
        {
            count = 0;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        dialogWindow.SetActive(true);
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        dialogWindow.SetActive(false);
        if(count >= 4)
        {
            isTalking = true;
            dialogWindow.SetActive(false);
        }
    }
}
