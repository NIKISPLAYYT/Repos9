using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float speed = 2;
    public Transform[] points;
    public int i;

    public Transform playerTransform;
    public float touchDistance = 0.1f;

    public GameObject player, loseMenu;

    void FixedUpdate()
    {
        transform.position = Vector2.MoveTowards(transform.position, points[i].position, speed * Time.fixedDeltaTime);
        if (Vector2.Distance(transform.position, points[i].position) < 0.2f)
        {
            if (i > 0)
            {
                i = 0;
            }
            else
            {
                i = 1;
            }
        }
    }

    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            Destroy(player);
            loseMenu.SetActive(true);
        }
    }
}
