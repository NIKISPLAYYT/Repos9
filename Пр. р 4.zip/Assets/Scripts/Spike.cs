using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Spike : MonoBehaviour
{
    public GameObject player, loseMenu, enemy;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            Destroy(player);
            loseMenu.SetActive(true);
        }
        if (collision.CompareTag("Enemy"))
        {
            Destroy(enemy);
        }
    }
}
