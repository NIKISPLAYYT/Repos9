using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TerrainGenerator : MonoBehaviour
{
    public Texture2D NoiseTexture;
    public Sprite Sprite2D;
    public int textureSize;
    public float seed;
    public float noiseFreq;
    public float terrFreq;
    public float Heighter;

    void NoiseGenerator()
    {
        NoiseTexture = new Texture2D(textureSize, textureSize);

        for (int i = 0; i < NoiseTexture.width; i++)
        {
            for (int j = 0; j < NoiseTexture.height; j++)
            {
                float p = Mathf.PerlinNoise((i + seed) * noiseFreq, (j + seed) * noiseFreq);
                NoiseTexture.SetPixel(i, j, new Color(p, p, p));
            }
            NoiseTexture.Apply();
        }
    }

    void TerrainGeneratorAlg()
    {
        for (int i = 0; i < NoiseTexture.width; i++)
        {
            float height = Mathf.PerlinNoise((i + seed) * noiseFreq, seed * terrFreq) * Heighter;

            for (int j = 0; j < height; j++)
            {
                if (NoiseTexture.GetPixel(i, j).r < 0.5f)
                {
                    GameObject go = new GameObject();
                    go.AddComponent<SpriteRenderer>();
                    go.GetComponent<SpriteRenderer>().sprite = Sprite2D;
                    go.transform.position = new Vector2(i, j);
                }
            }
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        seed = Random.Range(-100000, 100000);
        NoiseGenerator();
    }

    // Update is called once per frame
    void Update()
    {

    }
}
