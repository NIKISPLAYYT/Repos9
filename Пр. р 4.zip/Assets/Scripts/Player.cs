using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public GameObject player;
    public GameObject Arrow;
    private Rigidbody2D rb;
    private float jump = 200f;
    public bool isGround;
    public Transform feetPos;
    public float checkRad;
    public LayerMask whatIsGround;
    public float speed = 5f;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        isGround = Physics2D.OverlapCircle(feetPos.position, checkRad, whatIsGround);

        if (isGround == true && Input.GetKeyDown(KeyCode.Space))
        {
            rb.AddForce(new Vector2(rb.velocity.x, jump));
            
        }
        Vector3 movement = new Vector3(Input.GetAxis("Horizontal"), 0) * speed * Time.deltaTime;
        transform.Translate(movement);

        /*if (Input.GetMouseButtonDown(0))
        {
            GameObject newArrow = Instantiate(Arrow) as GameObject;
            newArrow.transform.position = this.transform.position;
            Rigidbody2D rb = newArrow.GetComponent<Rigidbody2D>();
            if (this.transform.localScale.x > 0)
            {
                rb.AddForce(transform.up * 6, ForceMode2D.Impulse);
            }
        }*/
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                rb.AddForce(new Vector2(rb.velocity.x, jump));
                isGround = true;
            }
        }
    }
}
